// controllers/authController.js
const User = require("../db/models/User");

exports.showRegister = (req, res) => {
  res.render("auth/register", { title: "Create account — FERAL", error: null, form: {} });
};

exports.register = async (req, res) => {
  const { name, email, password, confirmPassword } = req.body;

  if (!name || !email || !password) {
    return res.status(400).render("auth/register", {
      title: "Create account — FERAL",
      error: "Fill in every field to continue.",
      form: { name, email },
    });
  }
  if (password.length < 6) {
    return res.status(400).render("auth/register", {
      title: "Create account — FERAL",
      error: "Your password needs at least 6 characters.",
      form: { name, email },
    });
  }
  if (password !== confirmPassword) {
    return res.status(400).render("auth/register", {
      title: "Create account — FERAL",
      error: "Those passwords don't match.",
      form: { name, email },
    });
  }

  try {
    const user = await User.create({ name, email, password });
    req.session.user = User.toSafeJSON(user);
    res.redirect("/");
  } catch (err) {
    res.status(400).render("auth/register", {
      title: "Create account — FERAL",
      error: err.message,
      form: { name, email },
    });
  }
};

exports.showLogin = (req, res) => {
  res.render("auth/login", { title: "Log in — FERAL", error: null, form: {} });
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  const user = User.byEmail(email);

  if (!user || !(await User.verifyPassword(user, password))) {
    return res.status(401).render("auth/login", {
      title: "Log in — FERAL",
      error: "That email and password don't match an account.",
      form: { email },
    });
  }

  req.session.user = User.toSafeJSON(user);
  const redirectTo = req.session.redirectTo || "/";
  delete req.session.redirectTo;
  res.redirect(redirectTo);
};

exports.logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
};
