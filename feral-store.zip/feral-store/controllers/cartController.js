// controllers/cartController.js
const cart = require("../utils/cart");

exports.viewCart = (req, res) => {
  const { items, subtotal, shippingFee, total } = cart.hydrateCart(req);
  res.render("cart/index", {
    title: "Your bag — FERAL",
    items,
    subtotal,
    shippingFee,
    total,
    error: null,
  });
};

exports.addToCart = (req, res) => {
  const { productId } = req.params;
  const qty = Math.max(1, parseInt(req.body.qty, 10) || 1);

  try {
    cart.addToCart(req, productId, qty);
    res.redirect(req.body.redirectTo || "/cart");
  } catch (err) {
    res.redirect(`/products/${productId}?error=${encodeURIComponent(err.message)}`);
  }
};

exports.updateCartItem = (req, res) => {
  const { productId } = req.params;
  const qty = parseInt(req.body.qty, 10);

  try {
    cart.updateCartItem(req, productId, qty);
    res.redirect("/cart");
  } catch (err) {
    const { items, subtotal, shippingFee, total } = cart.hydrateCart(req);
    res.status(400).render("cart/index", {
      title: "Your bag — FERAL",
      items,
      subtotal,
      shippingFee,
      total,
      error: err.message,
    });
  }
};

exports.removeFromCart = (req, res) => {
  cart.removeFromCart(req, req.params.productId);
  res.redirect("/cart");
};
