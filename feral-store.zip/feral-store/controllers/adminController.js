// controllers/adminController.js
const Product = require("../db/models/Product");
const Order = require("../db/models/Order");

exports.dashboard = (req, res) => {
  const products = Product.all();
  const orders = Order.all();
  const revenue = +orders.reduce((sum, o) => sum + o.total, 0).toFixed(2);
  const lowStock = products.filter((p) => p.stock <= 10);

  res.render("admin/dashboard", {
    title: "Admin — FERAL",
    stats: {
      productCount: products.length,
      orderCount: orders.length,
      revenue,
      lowStockCount: lowStock.length,
    },
    recentOrders: orders.slice(0, 6),
    lowStock,
  });
};

exports.listProducts = (req, res) => {
  res.render("admin/products/index", {
    title: "Manage products — FERAL",
    products: Product.all(),
  });
};

exports.newProductForm = (req, res) => {
  res.render("admin/products/form", {
    title: "Add product — FERAL",
    product: null,
    error: null,
  });
};

exports.createProduct = (req, res) => {
  const { name, category, price, stock, image, description, featured } = req.body;

  if (!name || !category || !price || !stock) {
    return res.status(400).render("admin/products/form", {
      title: "Add product — FERAL",
      product: req.body,
      error: "Name, category, price, and stock are required.",
    });
  }

  Product.create({
    name,
    category,
    price: parseFloat(price),
    stock: parseInt(stock, 10),
    image: image || "/img/products/jacket-denim.svg",
    description: description || "",
    featured: featured === "on",
  });

  res.redirect("/admin/products");
};

exports.editProductForm = (req, res) => {
  const product = Product.byId(req.params.id);
  if (!product) {
    return res.status(404).render("error", {
      title: "Not found",
      message: "That product doesn't exist.",
    });
  }
  res.render("admin/products/form", {
    title: "Edit product — FERAL",
    product,
    error: null,
  });
};

exports.updateProduct = (req, res) => {
  const { name, category, price, stock, image, description, featured } = req.body;
  const product = Product.byId(req.params.id);

  if (!product) {
    return res.status(404).render("error", {
      title: "Not found",
      message: "That product doesn't exist.",
    });
  }

  if (!name || !category || !price || !stock) {
    return res.status(400).render("admin/products/form", {
      title: "Edit product — FERAL",
      product: { ...product, ...req.body },
      error: "Name, category, price, and stock are required.",
    });
  }

  Product.update(req.params.id, {
    name,
    category,
    price: parseFloat(price),
    stock: parseInt(stock, 10),
    image: image || product.image,
    description: description || "",
    featured: featured === "on",
  });

  res.redirect("/admin/products");
};

exports.deleteProduct = (req, res) => {
  Product.remove(req.params.id);
  res.redirect("/admin/products");
};

exports.listOrders = (req, res) => {
  res.render("admin/orders/index", {
    title: "All orders — FERAL",
    orders: Order.all(),
  });
};

exports.updateOrderStatus = (req, res) => {
  Order.updateStatus(req.params.id, req.body.status);
  res.redirect("/admin/orders");
};
