// controllers/shopController.js
const Product = require("../db/models/Product");

exports.home = (req, res) => {
  const all = Product.all();
  const featured = all.filter((p) => p.featured);
  const newArrivals = [...all].slice(-4).reverse();
  res.render("home", {
    title: "FERAL — Considered clothing",
    featured,
    newArrivals,
  });
};

exports.listProducts = (req, res) => {
  const { category, q } = req.query;
  let products = q ? Product.search(q) : Product.byCategory(category);
  const categories = Product.categories();

  res.render("products/index", {
    title: "Shop — FERAL",
    products,
    categories,
    activeCategory: category || "all",
    query: q || "",
  });
};

exports.showProduct = (req, res) => {
  const product = Product.byId(req.params.id);
  if (!product) {
    return res.status(404).render("error", {
      title: "Not found",
      message: "That piece doesn't exist, or has been retired.",
    });
  }
  const related = Product.byCategory(product.category)
    .filter((p) => p.id !== product.id)
    .slice(0, 3);

  res.render("products/show", {
    title: `${product.name} — FERAL`,
    product,
    related,
  });
};
