// controllers/orderController.js
const cartUtils = require("../utils/cart");
const Product = require("../db/models/Product");
const Order = require("../db/models/Order");

exports.showCheckout = (req, res) => {
  const { items, subtotal, shippingFee, total } = cartUtils.hydrateCart(req);
  if (items.length === 0) {
    return res.redirect("/cart");
  }
  res.render("cart/checkout", {
    title: "Checkout — FERAL",
    items,
    subtotal,
    shippingFee,
    total,
    error: null,
    form: {},
  });
};

exports.placeOrder = (req, res) => {
  const { items, subtotal, shippingFee, total } = cartUtils.hydrateCart(req);
  const { name, address, city, zip } = req.body;

  if (items.length === 0) {
    return res.redirect("/cart");
  }

  if (!name || !address || !city || !zip) {
    return res.status(400).render("cart/checkout", {
      title: "Checkout — FERAL",
      items,
      subtotal,
      shippingFee,
      total,
      error: "Fill in your full shipping address to place the order.",
      form: { name, address, city, zip },
    });
  }

  // Verify stock one more time before committing the order
  for (const item of items) {
    const product = Product.byId(item.productId);
    if (!product || product.stock < item.qty) {
      return res.status(400).render("cart/checkout", {
        title: "Checkout — FERAL",
        items,
        subtotal,
        shippingFee,
        total,
        error: `${item.name} no longer has enough stock. Update your bag and try again.`,
        form: { name, address, city, zip },
      });
    }
  }

  // Decrement stock + create order
  items.forEach((item) => Product.decrementStock(item.productId, item.qty));

  const order = Order.create({
    userId: req.session.user.id,
    items,
    total,
    shipping: { name, address, city, zip },
  });

  cartUtils.clearCart(req);
  res.redirect(`/orders/${order.id}/confirmation`);
};

exports.showConfirmation = (req, res) => {
  const order = Order.byId(req.params.id);
  if (!order || String(order.userId) !== String(req.session.user.id)) {
    return res.status(404).render("error", {
      title: "Not found",
      message: "We couldn't find that order.",
    });
  }
  res.render("cart/confirmation", {
    title: "Order placed — FERAL",
    order,
  });
};

exports.myOrders = (req, res) => {
  const orders = Order.byUser(req.session.user.id);
  res.render("orders/index", {
    title: "Your orders — FERAL",
    orders,
  });
};

exports.showOrder = (req, res) => {
  const order = Order.byId(req.params.id);
  if (!order || String(order.userId) !== String(req.session.user.id)) {
    return res.status(404).render("error", {
      title: "Not found",
      message: "We couldn't find that order.",
    });
  }
  res.render("orders/show", {
    title: `Order #${order.id} — FERAL`,
    order,
  });
};
