# FERAL — a small e-commerce store

A full-stack e-commerce storefront built with **Express.js**, **EJS**, and vanilla **HTML/CSS/JavaScript**. Built for a "Simple E-commerce Store" assignment, themed as a small fashion label.

## Features

- **Product catalog** — browsable grid with category filters and search
- **Product detail pages** — quantity stepper, stock indicator, related products
- **Shopping cart** — session-based, add/update/remove, live subtotal & shipping calculation
- **User accounts** — register / log in / log out with hashed passwords (bcrypt) and sessions
- **Order processing** — checkout with shipping address, stock validation, order confirmation, order history
- **Admin panel** — dashboard with stats, full product CRUD (add/edit/delete), order status management
- **Responsive design** — works down to mobile widths, with a slide-out mobile nav

## Tech stack

- **Backend:** Node.js + Express.js
- **Views:** EJS templates (server-rendered, no client framework needed)
- **Auth:** express-session + bcryptjs
- **Database:** a lightweight JSON file-backed store (`db/jsonStore.js`) — no native compilation required, so it installs anywhere. Each "table" (`products`, `users`, `orders`) is a JSON file in `db/data/`, but every model uses the same five methods (`findAll`, `findById`, `find`, `insert`, `update`, `remove`), so swapping in real SQLite or Postgres later only means rewriting that one file.

## Getting started

```bash
npm install
npm run seed     # populates products + demo accounts
npm start         # runs on http://localhost:3000
```

## Demo accounts

| Role     | Email                | Password      |
|----------|-----------------------|---------------|
| Shopper  | demo@feral.store      | password123   |
| Admin    | admin@feral.store     | admin123      |

Log in as the admin account and visit `/admin` to manage products and orders.

## Project structure

```
app.js                 # Express app entry point
controllers/            # route handler logic
routes/                 # route definitions
middleware/auth.js       # session/auth guards
utils/cart.js            # cart calculation helpers
db/
  jsonStore.js          # generic JSON file data engine
  models/                # Product, User, Order
  seed.js                # sample data + demo accounts
  data/                  # JSON "tables" (created at runtime)
views/                  # EJS templates
public/                 # CSS, JS, product SVG illustrations
scripts/gen-product-svgs.js  # regenerates the product line-art images
```

## Notes

- Cart and login both live in the server-side session, so they reset if the server restarts (session store is in-memory by default — fine for a class project, but swap in `connect-sqlite3` or Redis for production use).
- Product images are generated line-art SVGs (`scripts/gen-product-svgs.js`) rather than stock photos, to keep the project self-contained with no external image dependencies.
- Payment on checkout is fully simulated — no real card processing.
