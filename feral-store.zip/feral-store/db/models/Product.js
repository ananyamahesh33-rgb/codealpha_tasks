// db/models/Product.js
const store = require("../jsonStore");
const TABLE = "products";

const Product = {
  all() {
    return store.findAll(TABLE).sort((a, b) => a.id - b.id);
  },

  byId(id) {
    return store.findById(TABLE, id);
  },

  byCategory(category) {
    if (!category || category === "all") return Product.all();
    return store.filter(TABLE, (p) => p.category === category);
  },

  search(query) {
    const q = (query || "").toLowerCase().trim();
    if (!q) return Product.all();
    return store.filter(
      TABLE,
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
    );
  },

  categories() {
    const all = Product.all();
    return [...new Set(all.map((p) => p.category))];
  },

  create(data) {
    return store.insert(TABLE, data);
  },

  update(id, patch) {
    return store.update(TABLE, id, patch);
  },

  remove(id) {
    return store.remove(TABLE, id);
  },

  decrementStock(id, qty) {
    const product = Product.byId(id);
    if (!product) return null;
    const newStock = Math.max(0, product.stock - qty);
    return store.update(TABLE, id, { stock: newStock });
  },
};

module.exports = Product;
