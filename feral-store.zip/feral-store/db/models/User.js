// db/models/User.js
const bcrypt = require("bcryptjs");
const store = require("../jsonStore");
const TABLE = "users";

const User = {
  byId(id) {
    return store.findById(TABLE, id);
  },

  byEmail(email) {
    return store.find(
      TABLE,
      (u) => u.email.toLowerCase() === String(email).toLowerCase()
    );
  },

  async create({ name, email, password, isAdmin = false }) {
    const existing = User.byEmail(email);
    if (existing) {
      throw new Error("An account with that email already exists.");
    }
    const passwordHash = await bcrypt.hash(password, 10);
    return store.insert(TABLE, {
      name,
      email: email.toLowerCase(),
      passwordHash,
      isAdmin,
    });
  },

  async verifyPassword(user, password) {
    return bcrypt.compare(password, user.passwordHash);
  },

  toSafeJSON(user) {
    if (!user) return null;
    const { passwordHash, ...safe } = user;
    return safe;
  },
};

module.exports = User;
