// db/models/Order.js
const store = require("../jsonStore");
const TABLE = "orders";

const Order = {
  all() {
    return store.findAll(TABLE).sort((a, b) => b.id - a.id);
  },

  byId(id) {
    return store.findById(TABLE, id);
  },

  byUser(userId) {
    return store
      .filter(TABLE, (o) => String(o.userId) === String(userId))
      .sort((a, b) => b.id - a.id);
  },

  create({ userId, items, total, shipping }) {
    return store.insert(TABLE, {
      userId,
      items, // [{ productId, name, price, qty, image }]
      total,
      shipping, // { name, address, city, zip }
      status: "placed",
    });
  },

  updateStatus(id, status) {
    return store.update(TABLE, id, { status });
  },
};

module.exports = Order;
