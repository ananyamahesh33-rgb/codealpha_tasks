// db/seed.js
//
// Populates the store with an admin account and a starter catalog.
// Run with: npm run seed

const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");

const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const PRODUCTS = [
  {
    name: "Selvedge Raw Denim Jacket",
    category: "Outerwear",
    price: 188.0,
    stock: 14,
    image: "/img/products/jacket-denim.svg",
    description:
      "A boxy trucker jacket cut from 14oz Japanese selvedge denim. Unwashed indigo that breaks in and fades with wear — every crease becomes part of the garment's record.",
    featured: true,
  },
  {
    name: "Ash Wool Overcoat",
    category: "Outerwear",
    price: 312.0,
    stock: 8,
    image: "/img/products/coat-wool.svg",
    description:
      "Double-breasted overcoat in brushed ash-grey wool. Cut long, with a dropped shoulder for layering over knitwear through the coldest months.",
    featured: false,
  },
  {
    name: "Ink Oxford Shirt",
    category: "Tops",
    price: 78.0,
    stock: 26,
    image: "/img/products/shirt-oxford.svg",
    description:
      "A heavyweight cotton oxford in deep ink. Mother-of-pearl buttons, a back yoke seam, and a collar built to hold its shape with or without a tie.",
    featured: true,
  },
  {
    name: "Brass-Button Knit Polo",
    category: "Tops",
    price: 64.0,
    stock: 30,
    image: "/img/products/polo-knit.svg",
    description:
      "Fine-gauge cotton knit polo with brass buttons and a ribbed collar. Quietly textured — reads as a knit from a distance, sharp up close.",
    featured: false,
  },
  {
    name: "Stone Linen Tee",
    category: "Tops",
    price: 42.0,
    stock: 40,
    image: "/img/products/tee-linen.svg",
    description:
      "A heavyweight linen-cotton tee in warm stone. Boxy body, dropped shoulder seam, garment-washed for a worn-in hand from the first day.",
    featured: false,
  },
  {
    name: "Tapered Selvedge Jean",
    category: "Bottoms",
    price: 142.0,
    stock: 22,
    image: "/img/products/jean-tapered.svg",
    description:
      "Mid-rise, tapered through the leg, cut from the same 14oz selvedge as our jacket. Built to fade exactly where you sit, walk, and carry your phone.",
    featured: true,
  },
  {
    name: "Brass Pleat Trouser",
    category: "Bottoms",
    price: 128.0,
    stock: 18,
    image: "/img/products/trouser-pleat.svg",
    description:
      "A single forward pleat and a tapered ankle in a brushed brass-toned wool blend. Dresses up an oxford, dresses down a blazer.",
    featured: false,
  },
  {
    name: "Quarry Cargo Pant",
    category: "Bottoms",
    price: 118.0,
    stock: 24,
    image: "/img/products/pant-cargo.svg",
    description:
      "A six-pocket utility cargo in stone-washed cotton twill. Tapered enough to wear with boots, roomy enough to actually use the pockets.",
    featured: false,
  },
  {
    name: "Charcoal Merino Crewneck",
    category: "Knitwear",
    price: 96.0,
    stock: 20,
    image: "/img/products/knit-crewneck.svg",
    description:
      "14-gauge merino crewneck in charcoal. Fine enough to layer under a jacket, substantial enough to wear alone on a cold walk.",
    featured: true,
  },
  {
    name: "Cream Cable Cardigan",
    category: "Knitwear",
    price: 134.0,
    stock: 12,
    image: "/img/products/knit-cardigan.svg",
    description:
      "A heavyweight cable-knit cardigan in undyed cream wool. Horn buttons, patch pockets, and enough structure to wear as outerwear in spring.",
    featured: false,
  },
  {
    name: "Field Canvas Tote",
    category: "Accessories",
    price: 58.0,
    stock: 35,
    image: "/img/products/tote-canvas.svg",
    description:
      "16oz waxed canvas tote with leather strap reinforcement. Stands up on its own when empty, holds its shape when it isn't.",
    featured: false,
  },
  {
    name: "Saddle Leather Belt",
    category: "Accessories",
    price: 72.0,
    stock: 28,
    image: "/img/products/belt-leather.svg",
    description:
      "Full-grain saddle leather belt with a solid brass buckle. Will darken and soften with wear — no two will look the same after a year.",
    featured: false,
  },
];

function seed() {
  // Products
  const productsWithIds = PRODUCTS.map((p, i) => ({
    id: i + 1,
    ...p,
    createdAt: new Date().toISOString(),
  }));
  fs.writeFileSync(
    path.join(DATA_DIR, "products.json"),
    JSON.stringify(productsWithIds, null, 2)
  );

  // Admin + demo user
  const adminPasswordHash = bcrypt.hashSync("admin123", 10);
  const demoPasswordHash = bcrypt.hashSync("password123", 10);
  const users = [
    {
      id: 1,
      name: "Store Admin",
      email: "admin@feral.store",
      passwordHash: adminPasswordHash,
      isAdmin: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 2,
      name: "Demo Shopper",
      email: "demo@feral.store",
      passwordHash: demoPasswordHash,
      isAdmin: false,
      createdAt: new Date().toISOString(),
    },
  ];
  fs.writeFileSync(
    path.join(DATA_DIR, "users.json"),
    JSON.stringify(users, null, 2)
  );

  // Empty orders table
  fs.writeFileSync(path.join(DATA_DIR, "orders.json"), JSON.stringify([], null, 2));

  console.log("✓ Seeded", productsWithIds.length, "products");
  console.log("✓ Seeded 2 users:");
  console.log("   admin@feral.store / admin123  (admin)");
  console.log("   demo@feral.store  / password123  (shopper)");
  console.log("✓ Orders table reset");
}

seed();
