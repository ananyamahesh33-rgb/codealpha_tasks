// db/jsonStore.js
//
// A tiny file-backed data store. Each "table" is a JSON file in /db/data.
// This keeps the project dependency-free (no native compilation needed)
// while still giving every model a clean, swappable API:
// findAll / findById / find / insert / update / remove.
//
// To move to real SQLite or Postgres later, only this file needs to change —
// every model (Product, User, Order) calls the same five methods.

const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function filePath(table) {
  return path.join(DATA_DIR, `${table}.json`);
}

function readTable(table) {
  const file = filePath(table);
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, "[]");
    return [];
  }
  const raw = fs.readFileSync(file, "utf-8").trim();
  return raw ? JSON.parse(raw) : [];
}

function writeTable(table, rows) {
  fs.writeFileSync(filePath(table), JSON.stringify(rows, null, 2));
}

function nextId(rows) {
  return rows.reduce((max, r) => Math.max(max, r.id || 0), 0) + 1;
}

const store = {
  findAll(table) {
    return readTable(table);
  },

  findById(table, id) {
    const rows = readTable(table);
    return rows.find((r) => String(r.id) === String(id)) || null;
  },

  find(table, predicate) {
    const rows = readTable(table);
    return rows.find(predicate) || null;
  },

  filter(table, predicate) {
    const rows = readTable(table);
    return rows.filter(predicate);
  },

  insert(table, data) {
    const rows = readTable(table);
    const row = { id: nextId(rows), ...data, createdAt: new Date().toISOString() };
    rows.push(row);
    writeTable(table, rows);
    return row;
  },

  update(table, id, patch) {
    const rows = readTable(table);
    const idx = rows.findIndex((r) => String(r.id) === String(id));
    if (idx === -1) return null;
    rows[idx] = { ...rows[idx], ...patch, updatedAt: new Date().toISOString() };
    writeTable(table, rows);
    return rows[idx];
  },

  remove(table, id) {
    const rows = readTable(table);
    const next = rows.filter((r) => String(r.id) !== String(id));
    writeTable(table, next);
    return next.length !== rows.length;
  },
};

module.exports = store;
