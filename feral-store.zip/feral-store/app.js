// app.js
require("dotenv").config();
const express = require("express");
const session = require("express-session");
const methodOverride = require("method-override");
const path = require("path");

const { attachUser } = require("./middleware/auth");
const shopRoutes = require("./routes/shop");
const authRoutes = require("./routes/auth");
const cartRoutes = require("./routes/cart");
const adminRoutes = require("./routes/admin");

const app = express();
const PORT = process.env.PORT || 3000;

// View engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Body parsing & static files
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride("_method"));
app.use(express.static(path.join(__dirname, "public")));

// Sessions (cart + login both live here)
app.use(
  session({
    secret: process.env.SESSION_SECRET || "feral-dev-secret",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }, // 1 week
  })
);

app.use(attachUser);

// Routes
app.use("/", shopRoutes);
app.use("/", authRoutes);
app.use("/", cartRoutes);
app.use("/admin", adminRoutes);

// 404
app.use((req, res) => {
  res.status(404).render("error", {
    title: "Page not found — FERAL",
    message: "That page doesn't exist. It may have been moved or never made.",
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render("error", {
    title: "Something went wrong — FERAL",
    message: "Something broke on our end. Try again in a moment.",
  });
});

app.listen(PORT, () => {
  console.log(`\n  FERAL is running → http://localhost:${PORT}\n`);
});
