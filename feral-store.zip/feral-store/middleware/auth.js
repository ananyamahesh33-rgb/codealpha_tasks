// middleware/auth.js

function attachUser(req, res, next) {
  res.locals.currentUser = req.session.user || null;
  res.locals.cartCount = (req.session.cart || []).reduce(
    (sum, item) => sum + item.qty,
    0
  );
  next();
}

function requireAuth(req, res, next) {
  if (!req.session.user) {
    req.session.redirectTo = req.originalUrl;
    return res.redirect("/login");
  }
  next();
}

function requireGuest(req, res, next) {
  if (req.session.user) {
    return res.redirect("/");
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user || !req.session.user.isAdmin) {
    return res.status(403).render("error", {
      title: "Not allowed",
      message: "You need an admin account to view this page.",
    });
  }
  next();
}

module.exports = { attachUser, requireAuth, requireGuest, requireAdmin };
