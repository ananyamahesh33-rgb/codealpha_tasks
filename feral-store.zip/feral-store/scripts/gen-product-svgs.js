// scripts/gen-product-svgs.js
// Generates editorial line-art SVG placeholders for each product —
// a simple garment silhouette on a paper background with the category
// label, so the catalog looks intentional rather than using broken
// image links or generic gray boxes.

const fs = require("fs");
const path = require("path");

const OUT_DIR = path.join(__dirname, "..", "public", "img", "products");
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

const PAPER = "#F2EDE3";
const INK = "#181614";
const LINE = "#2B2724";

function wrap(inner, bg = PAPER) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 600">
  <rect width="480" height="600" fill="${bg}"/>
  <g stroke="${LINE}" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round">
    ${inner}
  </g>
</svg>`;
}

const SHAPES = {
  "jacket-denim": `
    <path d="M150 150 L170 110 H310 L330 150 L300 175 V470 H180 V175 Z"/>
    <path d="M170 110 L240 150 L310 110" />
    <path d="M150 150 L100 260 L130 280 L170 200" />
    <path d="M330 150 L380 260 L350 280 L310 200" />
    <line x1="240" y1="175" x2="240" y2="470"/>
    <circle cx="240" cy="220" r="4" fill="${LINE}"/>
    <circle cx="240" cy="280" r="4" fill="${LINE}"/>
    <circle cx="240" cy="340" r="4" fill="${LINE}"/>
    <rect x="190" y="230" width="30" height="35"/>
    <rect x="260" y="230" width="30" height="35"/>
  `,
  "coat-wool": `
    <path d="M160 145 L180 100 H300 L320 145 L300 180 V500 H180 V180 Z"/>
    <path d="M180 100 L240 150 L300 100" />
    <path d="M160 145 L95 270 L130 295 L180 200" />
    <path d="M320 145 L385 270 L350 295 L300 200" />
    <line x1="205" y1="180" x2="205" y2="480"/>
    <line x1="275" y1="180" x2="275" y2="480"/>
    <circle cx="205" cy="230" r="4" fill="${LINE}"/>
    <circle cx="205" cy="290" r="4" fill="${LINE}"/>
    <circle cx="205" cy="350" r="4" fill="${LINE}"/>
  `,
  "shirt-oxford": `
    <path d="M170 140 L195 105 H285 L310 140 L290 165 V460 H190 V165 Z"/>
    <path d="M195 105 L240 145 L285 105" />
    <path d="M170 140 L120 220 L150 245 L190 185" />
    <path d="M310 140 L360 220 L330 245 L290 185" />
    <line x1="240" y1="165" x2="240" y2="460"/>
    <circle cx="240" cy="200" r="3.5" fill="${LINE}"/>
    <circle cx="240" cy="250" r="3.5" fill="${LINE}"/>
    <circle cx="240" cy="300" r="3.5" fill="${LINE}"/>
    <circle cx="240" cy="350" r="3.5" fill="${LINE}"/>
    <circle cx="240" cy="400" r="3.5" fill="${LINE}"/>
  `,
  "polo-knit": `
    <path d="M175 150 L200 115 H280 L305 150 L285 175 V450 H195 V175 Z"/>
    <path d="M200 115 L240 150 L280 115" />
    <path d="M175 150 L135 215 L160 235 L195 195" />
    <path d="M305 150 L345 215 L320 235 L285 195" />
    <line x1="225" y1="150" x2="225" y2="200"/>
    <line x1="255" y1="150" x2="255" y2="200"/>
    <circle cx="240" cy="170" r="3.5" fill="${LINE}"/>
    <circle cx="240" cy="195" r="3.5" fill="${LINE}"/>
  `,
  "tee-linen": `
    <path d="M180 160 L205 125 H275 L300 160 L282 180 V440 H198 V180 Z"/>
    <path d="M205 125 L240 158 L275 125" />
    <path d="M180 160 L145 210 L168 228 L198 192" />
    <path d="M300 160 L335 210 L312 228 L282 192" />
  `,
  "jean-tapered": `
    <path d="M195 110 H285 L295 280 L270 480 H250 L240 320 L230 480 H210 L185 280 Z"/>
    <line x1="240" y1="110" x2="240" y2="320"/>
    <path d="M195 110 L195 150 L285 150 L285 110"/>
    <rect x="205" y="125" width="22" height="20"/>
    <rect x="253" y="125" width="22" height="20"/>
  `,
  "trouser-pleat": `
    <path d="M190 110 H290 L300 280 L275 480 H255 L240 330 L225 480 H205 L180 280 Z"/>
    <line x1="240" y1="115" x2="240" y2="300"/>
    <line x1="215" y1="115" x2="218" y2="160"/>
    <line x1="265" y1="115" x2="262" y2="160"/>
  `,
  "pant-cargo": `
    <path d="M188 108 H292 L302 282 L276 482 H254 L240 332 L226 482 H204 L178 282 Z"/>
    <line x1="240" y1="112" x2="240" y2="300"/>
    <rect x="195" y="260" width="34" height="42"/>
    <rect x="251" y="260" width="34" height="42"/>
    <rect x="195" y="320" width="22" height="16"/>
    <rect x="263" y="320" width="22" height="16"/>
  `,
  "knit-crewneck": `
    <path d="M175 165 L205 120 H275 L305 165 L283 188 V450 H197 V188 Z"/>
    <path d="M205 120 Q240 150 275 120" />
    <path d="M175 165 L130 225 L155 248 L197 200" />
    <path d="M305 165 L350 225 L325 248 L283 200" />
    <line x1="175" y1="180" x2="305" y2="180" stroke-dasharray="3 6"/>
    <line x1="180" y1="260" x2="300" y2="260" stroke-dasharray="3 6"/>
    <line x1="183" y1="340" x2="297" y2="340" stroke-dasharray="3 6"/>
  `,
  "knit-cardigan": `
    <path d="M170 155 L198 112 H282 L310 155 L288 180 V470 H192 V180 Z"/>
    <path d="M198 112 L240 150 L282 112" />
    <path d="M170 155 L122 222 L148 246 L192 195" />
    <path d="M310 155 L358 222 L332 246 L288 195" />
    <line x1="240" y1="180" x2="240" y2="470"/>
    <circle cx="240" cy="225" r="4" fill="${LINE}"/>
    <circle cx="240" cy="285" r="4" fill="${LINE}"/>
    <circle cx="240" cy="345" r="4" fill="${LINE}"/>
    <circle cx="240" cy="405" r="4" fill="${LINE}"/>
  `,
  "tote-canvas": `
    <path d="M150 220 H330 L315 470 H165 Z"/>
    <path d="M190 220 V170 Q190 140 240 140 Q290 140 290 170 V220"/>
    <line x1="150" y1="290" x2="330" y2="290"/>
  `,
  "belt-leather": `
    <rect x="90" y="270" width="300" height="60" rx="6"/>
    <rect x="200" y="278" width="80" height="44" rx="4"/>
    <circle cx="240" cy="300" r="9"/>
    <line x1="320" y1="280" x2="320" y2="320"/>
    <line x1="335" y1="280" x2="335" y2="320"/>
    <line x1="350" y1="280" x2="350" y2="320"/>
  `,
};

let count = 0;
for (const [slug, shape] of Object.entries(SHAPES)) {
  const svg = wrap(shape);
  fs.writeFileSync(path.join(OUT_DIR, `${slug}.svg`), svg);
  count++;
}

console.log(`✓ Generated ${count} product SVGs in ${OUT_DIR}`);
