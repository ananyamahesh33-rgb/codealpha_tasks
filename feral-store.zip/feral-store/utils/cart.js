// utils/cart.js
const Product = require("../db/models/Product");

function getCart(req) {
  if (!req.session.cart) req.session.cart = [];
  return req.session.cart;
}

function addToCart(req, productId, qty = 1) {
  const cart = getCart(req);
  const product = Product.byId(productId);
  if (!product) throw new Error("Product not found.");

  const existing = cart.find((item) => String(item.productId) === String(productId));
  const currentQty = existing ? existing.qty : 0;
  const desiredQty = currentQty + qty;

  if (desiredQty > product.stock) {
    throw new Error(`Only ${product.stock} left in stock.`);
  }

  if (existing) {
    existing.qty = desiredQty;
  } else {
    cart.push({ productId: product.id, qty });
  }
  return cart;
}

function updateCartItem(req, productId, qty) {
  const cart = getCart(req);
  const product = Product.byId(productId);
  if (!product) throw new Error("Product not found.");
  if (qty > product.stock) {
    throw new Error(`Only ${product.stock} left in stock.`);
  }
  const item = cart.find((i) => String(i.productId) === String(productId));
  if (item) {
    if (qty <= 0) {
      return removeFromCart(req, productId);
    }
    item.qty = qty;
  }
  return cart;
}

function removeFromCart(req, productId) {
  const cart = getCart(req);
  req.session.cart = cart.filter(
    (item) => String(item.productId) !== String(productId)
  );
  return req.session.cart;
}

function clearCart(req) {
  req.session.cart = [];
}

function hydrateCart(req) {
  const cart = getCart(req);
  const items = cart
    .map((item) => {
      const product = Product.byId(item.productId);
      if (!product) return null;
      return {
        productId: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        qty: item.qty,
        stock: product.stock,
        lineTotal: +(product.price * item.qty).toFixed(2),
      };
    })
    .filter(Boolean);

  const subtotal = +items.reduce((sum, i) => sum + i.lineTotal, 0).toFixed(2);
  const shippingFee = subtotal === 0 || subtotal >= 150 ? 0 : 9.5;
  const total = +(subtotal + shippingFee).toFixed(2);

  return { items, subtotal, shippingFee, total };
}

module.exports = {
  getCart,
  addToCart,
  updateCartItem,
  removeFromCart,
  clearCart,
  hydrateCart,
};
