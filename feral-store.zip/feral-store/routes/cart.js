// routes/cart.js
const express = require("express");
const router = express.Router();
const cartController = require("../controllers/cartController");
const orderController = require("../controllers/orderController");
const { requireAuth } = require("../middleware/auth");

router.get("/cart", cartController.viewCart);
router.post("/cart/add/:productId", cartController.addToCart);
router.post("/cart/update/:productId", cartController.updateCartItem);
router.post("/cart/remove/:productId", cartController.removeFromCart);

router.get("/checkout", requireAuth, orderController.showCheckout);
router.post("/checkout", requireAuth, orderController.placeOrder);
router.get("/orders/:id/confirmation", requireAuth, orderController.showConfirmation);

router.get("/orders", requireAuth, orderController.myOrders);
router.get("/orders/:id", requireAuth, orderController.showOrder);

module.exports = router;
