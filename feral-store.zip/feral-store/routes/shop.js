// routes/shop.js
const express = require("express");
const router = express.Router();
const shopController = require("../controllers/shopController");

router.get("/", shopController.home);
router.get("/products", shopController.listProducts);
router.get("/products/:id", shopController.showProduct);

module.exports = router;
