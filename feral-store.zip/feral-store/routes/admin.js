// routes/admin.js
const express = require("express");
const router = express.Router();
const adminController = require("../controllers/adminController");
const { requireAuth, requireAdmin } = require("../middleware/auth");

router.use(requireAuth, requireAdmin);

router.get("/", adminController.dashboard);

router.get("/products", adminController.listProducts);
router.get("/products/new", adminController.newProductForm);
router.post("/products", adminController.createProduct);
router.get("/products/:id/edit", adminController.editProductForm);
router.post("/products/:id", adminController.updateProduct);
router.post("/products/:id/delete", adminController.deleteProduct);

router.get("/orders", adminController.listOrders);
router.post("/orders/:id/status", adminController.updateOrderStatus);

module.exports = router;
